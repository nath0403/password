package client;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.ResourceBundle;

public class PasswordChange {
	
	public static void main(String args[]){
		JSchExampleSSHConnection pwd_change = new JSchExampleSSHConnection();
		ResourceBundle rb;
        System.out.println("in rb");
        rb = ResourceBundle.getBundle("password.servers");
        ArrayList<String> server = new ArrayList<String>();
        //String FILE_DIR=rb.getString("server1");
        Enumeration<String> enumeration = rb.getKeys();
        while (enumeration.hasMoreElements()) {
       String temp = enumeration.nextElement();
        //	server.add(i,rb.getString(enumeration.nextElement()));
        System.out.println("" + rb.getString(temp));
        server.add(rb.getString(temp));
        //   i++;
        }
        System.out.println("after while loop" );
        for (int counter = 0; counter < server.size(); counter++) { 	
        	String temp_server = server.get(counter);
            System.out.println(server.get(counter)); 
            
                String Host = temp_server.substring(0, temp_server.indexOf('#'));
                String user = temp_server.substring(temp_server.indexOf('#')+1,temp_server.indexOf('&') );
                String old_password =  temp_server.substring(temp_server.indexOf('&')+1,temp_server.indexOf('%') );
                String new_Password  = temp_server.substring(temp_server.indexOf('%')+1 );
                System.out.println(Host + "\n" + user +"\n" + old_password+"\n" + new_Password ); 
                pwd_change.change_password(Host, user, old_password, new_Password);
                System.out.println("The password of"+ Host + "is changed to  " + new_Password ); 
             
        }      
    }


	}

