package client;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import expectj.ExpectJ;
import expectj.Spawn;

public class JSchExampleSSHConnection {
	/**
	 * JSch Example Tutorial
	 * Java SSH Connection Program
	 */
	public static void main(String[] args) {
	    

	}
public void change_password(String host , String user, String old_password, String new_password) {
	/*String host="172.17.24.45";
    String user="ichargegprs";
    String password="Rama@2017";*/
	try{
    	java.util.Properties config = new java.util.Properties(); 
    	config.put("StrictHostKeyChecking", "no");
    	JSch jsch = new JSch();
        Session session=jsch.getSession(user, host, 22);
    	session.setPassword(old_password);
    	session.setConfig(config);
    	session.connect();
    	System.out.println("Connected");
    	Channel channel=session.openChannel("shell");
        ExpectJ expectinator = new ExpectJ();
        channel.connect(1000);
        // Fork the process
        Spawn shell = expectinator.spawn(channel);
        // Talk to it
        shell.send("passwd\n");
        shell.expect("UNIX password:");
        shell.send(old_password+"\r");
        shell.expect("password:");
        shell.send(new_password +"\r");
        shell.expect("password:");
        shell.send(new_password+"\r");
        shell.send("exit\n");    
        shell.expectClose();
       // channel.connect();
      // Create a new ExpectJ object with a timeout of 5s
      session.disconnect();
      System.out.println("DONE");
    }catch(Exception e){
    	e.printStackTrace();
    }
}
}
